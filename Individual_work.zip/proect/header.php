<div class="nav"><!--panela de navigare-->
        <div class="container"><!--Ca sus, ca sa fie contentul in centru, ca in video-->
            <div class="nav_content"><!--aici deam contentul pentru nav-->
                <a href="index.php" class="nav_link">Домашняя</a>
                <a href="categories.php" class="nav_link">Категории</a>
                <a href="feed.php" class="nav_link">Отзывы</a>
                <a href="contact.php" class="nav_link">Контакты</a>
                <a href="crud/home.php" class="nav_link">Добавить в БД</a>
                <a href="crud/log_in.php" class="nav_link"><img src="img/log-in.svg" class="img" alt="log in"></a>
            </div>
        </div><!--content-->
    </div><!--nav-->